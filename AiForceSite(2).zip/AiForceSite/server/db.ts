import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";

console.log("Setting up PostgreSQL connection...");

// Use individual environment variables if DATABASE_URL is incomplete
let connectionConfig: any;

if (process.env.PGHOST && process.env.PGPORT && process.env.PGUSER && process.env.PGDATABASE) {
  console.log("Using individual PostgreSQL environment variables");
  connectionConfig = {
    host: process.env.PGHOST,
    port: parseInt(process.env.PGPORT),
    username: process.env.PGUSER,
    password: process.env.PGPASSWORD,
    database: process.env.PGDATABASE,
    ssl: 'require'
  };
} else if (process.env.DATABASE_URL) {
  console.log("Using DATABASE_URL");
  connectionConfig = process.env.DATABASE_URL;
} else {
  throw new Error("No database configuration found");
}

const sql = postgres(connectionConfig);
export const db = drizzle(sql);