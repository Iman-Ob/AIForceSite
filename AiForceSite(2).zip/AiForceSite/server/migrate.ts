import { db } from "./db";
import { products, services, contacts } from "@shared/schema";
import { sql } from "drizzle-orm";

async function createTables() {
  try {
    console.log("Creating tables...");
    
    // Create tables if they don't exist
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS products (
        id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
        name text NOT NULL,
        description text NOT NULL,
        status varchar NOT NULL,
        features text[] NOT NULL DEFAULT ARRAY[]::text[]
      )
    `);
    
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS services (
        id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
        name text NOT NULL,
        category text NOT NULL,
        description text NOT NULL,
        features text[] NOT NULL DEFAULT ARRAY[]::text[],
        starting_price integer NOT NULL,
        icon varchar NOT NULL DEFAULT 'fas fa-cogs'
      )
    `);
    
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS contacts (
        id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
        name text NOT NULL,
        organization text,
        email text NOT NULL,
        mission_type text NOT NULL,
        message text NOT NULL,
        created_at text NOT NULL DEFAULT now()::text
      )
    `);
    
    console.log("Tables created successfully!");
    
    // Seed some initial data
    await seedData();
    
  } catch (error) {
    console.error("Error creating tables:", error);
    process.exit(1);
  }
}

async function seedData() {
  try {
    console.log("Seeding initial data...");
    
    // Check if we already have data
    const existingProducts = await db.select().from(products);
    const existingServices = await db.select().from(services);
    
    if (existingProducts.length === 0) {
      await db.insert(products).values([
        {
          name: "AI Assistant Platform",
          description: "Intelligent AI agents that automate complex business processes and workflows.",
          status: "DEPLOYED",
          features: ["Multi-agent coordination", "Real-time decision making", "Enterprise integration"]
        },
        {
          name: "Workflow Automation",
          description: "Intelligent automation platform that streamlines business processes and reduces manual work.",
          status: "ACTIVE",
          features: ["Process optimization", "Predictive analytics", "Custom workflows"]
        },
        {
          name: "Analytics Dashboard",
          description: "Real-time business intelligence with enterprise-grade analytics and reporting.",
          status: "BETA",
          features: ["Live data streams", "Advanced visualizations", "Anomaly detection"]
        }
      ]);
    }
    
    if (existingServices.length === 0) {
      await db.insert(services).values([
        {
          name: "Custom AI Development",
          category: "Development Team",
          description: "End-to-end development of AI systems tailored to your business requirements.",
          features: ["Technical architecture", "Model training", "System integration", "24/7 maintenance"],
          startingPrice: 12500,
          icon: "fas fa-laptop-code"
        },
        {
          name: "Process Optimization",
          category: "Strategy & Operations",
          description: "Optimize business processes using intelligent automation and workflow analysis.",
          features: ["Workflow analysis", "Process automation", "Performance metrics", "Continuous optimization"],
          startingPrice: 7500,
          icon: "fas fa-cogs"
        },
        {
          name: "AI Training & Support",
          category: "Training & Development", 
          description: "Comprehensive training programs for teams implementing AI solutions.",
          features: ["Team workshops", "Technical documentation", "Best practices guide", "Ongoing consultation"],
          startingPrice: 2500,
          icon: "fas fa-graduation-cap"
        }
      ]);
    }
    
    console.log("Data seeded successfully!");
    
  } catch (error) {
    console.error("Error seeding data:", error);
  }
}

// Run migration if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  createTables().then(() => {
    console.log("Migration completed!");
    process.exit(0);
  });
}