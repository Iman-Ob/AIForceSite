export default function MissionSection() {
  const missionCards = [
    {
      icon: "fas fa-brain",
      color: "mission-blue",
      title: "AI Development",
      description: "Machine learning solutions that adapt to your business needs and grow with your requirements."
    },
    {
      icon: "fas fa-cogs",
      color: "mission-green",
      title: "Process Automation",
      description: "Streamlined workflows that reduce manual work and increase productivity across your organization."
    },
    {
      icon: "fas fa-shield-alt",
      color: "mission-orange",
      title: "Secure Solutions",
      description: "Enterprise-grade security protocols that protect your data and ensure compliance standards."
    }
  ];

  return (
    <section id="mission" className="py-20 bg-tactical-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-tactical-100 mb-6">
            <i className="fas fa-target text-mission-blue mr-4"></i>OUR MISSION
          </h2>
          <div className="w-24 h-1 bg-mission-blue mx-auto mb-8"></div>
          <p className="text-xl md:text-2xl text-tactical-300 max-w-4xl mx-auto leading-relaxed">
            We help businesses succeed by implementing AI solutions that drive growth through smart, practical innovation.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {missionCards.map((card, index) => (
            <div key={index} className="bg-tactical-700 rounded-xl p-8 hover:bg-tactical-600 transition-all duration-300 transform hover:scale-105">
              <div className="text-center">
                <div className={`w-16 h-16 bg-${card.color} rounded-full flex items-center justify-center mx-auto mb-6`}>
                  <i className={`${card.icon} text-2xl text-white`}></i>
                </div>
                <h3 className="text-xl font-bold text-tactical-100 mb-4">{card.title}</h3>
                <p className="text-tactical-300">{card.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
