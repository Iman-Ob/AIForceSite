export default function Footer() {
  const quickLinks = [
    { href: "#mission", label: "About" },
    { href: "#vision", label: "Vision" },
    { href: "#products", label: "Projects" },
    { href: "#services", label: "Services" },
  ];

  const supportLinks = [
    { href: "#", label: "Documentation" },
    { href: "#", label: "Training" },
    { href: "#contact", label: "Contact" },
    { href: "#", label: "Support" },
  ];

  const socialLinks = [
    { href: "#", icon: "fab fa-linkedin", platform: "LinkedIn" },
    { href: "#", icon: "fab fa-twitter", platform: "Twitter" },
    { href: "#", icon: "fab fa-github", platform: "GitHub" },
  ];

  return (
    <footer className="bg-tactical-900 border-t border-tactical-700 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <img 
              src="data:image/svg+xml,%3Csvg width='200' height='100' xmlns='http://www.w3.org/2000/svg'%3E%3Crect width='200' height='100' fill='%23a0aec0'/%3E%3Ctext x='100' y='55' font-family='Arial, sans-serif' font-size='20' font-weight='bold' text-anchor='middle' fill='%23ffffff'%3EAIFORCE%3C/text%3E%3C/svg%3E"
              alt="AIFORCE" 
              className="h-16 w-auto mb-6"
            />
            <p className="text-tactical-400 mb-4">
              Smart AI solutions for businesses that need efficient automation and data-driven insights.
            </p>
            <div className="flex space-x-4">
              {socialLinks.map((social, index) => (
                <a 
                  key={index} 
                  href={social.href} 
                  className="text-tactical-400 hover:text-mission-blue transition-colors duration-200"
                  aria-label={social.platform}
                >
                  <i className={`${social.icon} text-xl`}></i>
                </a>
              ))}
            </div>
          </div>
          
          <div>
            <h4 className="text-tactical-100 font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <a 
                    href={link.href} 
                    className="text-tactical-400 hover:text-mission-blue transition-colors duration-200"
                    onClick={(e) => {
                      e.preventDefault();
                      const target = document.querySelector(link.href);
                      if (target) {
                        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                      }
                    }}
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="text-tactical-100 font-semibold mb-4">Support</h4>
            <ul className="space-y-2">
              {supportLinks.map((link, index) => (
                <li key={index}>
                  <a 
                    href={link.href} 
                    className="text-tactical-400 hover:text-mission-blue transition-colors duration-200"
                    onClick={(e) => {
                      if (link.href.startsWith("#")) {
                        e.preventDefault();
                        const target = document.querySelector(link.href);
                        if (target) {
                          target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                        }
                      }
                    }}
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <div className="border-t border-tactical-700 mt-8 pt-8 text-center">
          <p className="text-tactical-400">
            © 2024 AIFORCE. All rights reserved. Building the future with AI.
          </p>
        </div>
      </div>
    </footer>
  );
}
