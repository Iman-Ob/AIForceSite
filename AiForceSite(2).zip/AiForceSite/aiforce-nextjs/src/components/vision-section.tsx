'use client'
  const visionPoints = [
    {
      icon: "fas fa-rocket",
      color: "mission-blue",
      title: "Fast Implementation",
      description: "Quick implementation cycles that get your AI solutions up and running efficiently."
    },
    {
      icon: "fas fa-chart-line",
      color: "mission-green",
      title: "Data Insights",
      description: "Comprehensive analytics and monitoring across all your business processes."
    },
    {
      icon: "fas fa-trophy",
      color: "mission-orange",
      title: "Competitive Edge",
      description: "Proven results that help establish market leadership and business growth."
    }
  ];

  return (
    <section id="vision" className="py-20 bg-tactical-900 relative">
      {/* Background tactical grid */}
      <div className="absolute inset-0 opacity-5">
        <div 
          className="w-full h-full"
          style={{
            backgroundImage: 'radial-gradient(circle, #4299e1 1px, transparent 1px)',
            backgroundSize: '50px 50px'
          }}
        ></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-tactical-100 mb-6">
            <i className="fas fa-eye text-mission-blue mr-4"></i>OUR VISION
          </h2>
          <div className="w-24 h-1 bg-mission-blue mx-auto mb-8"></div>
          <p className="text-xl md:text-2xl text-tactical-300 max-w-4xl mx-auto leading-relaxed">
            Lead the market in today's AI revolution. We deliver speed, innovation, and sustainable growth.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            {visionPoints.map((point, index) => (
              <div key={index} className="flex items-start space-x-4">
                <div className={`flex-shrink-0 w-8 h-8 bg-${point.color} rounded-full flex items-center justify-center`}>
                  <i className={`${point.icon} text-white text-sm`}></i>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-tactical-100 mb-2">{point.title}</h3>
                  <p className="text-tactical-300">{point.description}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="relative">
            {/* Tactical radar display */}
            <div className="bg-tactical-800 rounded-2xl p-8 shadow-2xl">
              <div className="aspect-square bg-tactical-700 rounded-xl relative overflow-hidden">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-64 h-64 border-2 border-mission-blue rounded-full relative">
                    <div className="absolute inset-4 border border-mission-blue/50 rounded-full"></div>
                    <div className="absolute inset-8 border border-mission-blue/30 rounded-full"></div>
                    <div className="absolute top-1/2 left-1/2 w-2 h-2 bg-mission-blue rounded-full transform -translate-x-1/2 -translate-y-1/2"></div>
                    
                    {/* Radar sweep animation */}
                    <div className="absolute top-1/2 left-1/2 w-32 h-0.5 bg-mission-blue transform -translate-y-0.5 origin-left radar-sweep"></div>
                    
                    {/* Target blips */}
                    <div className="absolute top-8 right-16 w-2 h-2 bg-mission-green rounded-full animate-pulse"></div>
                    <div className="absolute bottom-12 left-20 w-2 h-2 bg-mission-green rounded-full animate-pulse"></div>
                    <div className="absolute top-20 left-8 w-2 h-2 bg-mission-orange rounded-full animate-pulse"></div>
                  </div>
                </div>
              </div>
              <div className="mt-4 text-center">
                <p className="text-tactical-400 text-sm">BUSINESS INTELLIGENCE DASHBOARD</p>
                <p className="text-mission-blue text-xs">SYSTEM STATUS: OPTIMAL</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
