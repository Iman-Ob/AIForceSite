import { useState, useEffect } from "react";

export default function Navigation() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("home");

  useEffect(() => {
    const updateActiveNav = () => {
      const scrollPos = window.scrollY + 100;
      const sections = document.querySelectorAll('section[id]');
      
      sections.forEach(section => {
        const element = section as HTMLElement;
        const top = element.offsetTop;
        const bottom = top + element.offsetHeight;
        const id = element.getAttribute('id');
        
        if (scrollPos >= top && scrollPos <= bottom && id) {
          setActiveSection(id);
        }
      });
    };

    window.addEventListener('scroll', updateActiveNav);
    updateActiveNav();
    
    return () => window.removeEventListener('scroll', updateActiveNav);
  }, []);

  const navItems = [
    { href: "#home", label: "Home", id: "home" },
    { href: "#mission", label: "About", id: "mission" },
    { href: "#vision", label: "Vision", id: "vision" },
    { href: "#products", label: "Products", id: "products" },
    { href: "#services", label: "Services", id: "services" },
    { href: "#contact", label: "Contact", id: "contact" },
    { href: "#admin", label: "Admin", id: "admin", special: true },
  ];

  const handleNavClick = (href: string) => {
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-tactical-800/95 backdrop-blur-sm border-b border-tactical-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center">
            <img 
              src="data:image/svg+xml,%3Csvg width='200' height='100' xmlns='http://www.w3.org/2000/svg'%3E%3Crect width='200' height='100' fill='%23a0aec0'/%3E%3Ctext x='100' y='55' font-family='Arial, sans-serif' font-size='20' font-weight='bold' text-anchor='middle' fill='%23ffffff'%3EAIFORCE%3C/text%3E%3C/svg%3E" 
              alt="AIFORCE Logo" 
              className="h-10 w-auto"
            />
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.href)}
                  className={`nav-link relative px-3 py-2 text-sm font-medium transition-colors duration-200 ${
                    activeSection === item.id
                      ? "active text-tactical-100"
                      : item.special
                        ? "text-mission-orange hover:text-orange-300"
                        : "text-tactical-400 hover:text-mission-blue"
                  }`}
                >
                  {item.special && <i className="fas fa-cog mr-1"></i>}
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              type="button"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-tactical-400 hover:text-tactical-100 hover:bg-tactical-700 focus:outline-none"
            >
              <i className="fas fa-bars"></i>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation Menu */}
      <div className={`mobile-menu md:hidden bg-tactical-800 border-t border-tactical-700 ${isMobileMenuOpen ? 'block' : 'hidden'}`}>
        <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.href)}
              className={`block w-full text-left px-3 py-2 text-base font-medium transition-colors duration-200 ${
                item.special
                  ? "text-mission-orange hover:text-orange-300"
                  : "text-tactical-400 hover:text-mission-blue"
              }`}
            >
              {item.special && <i className="fas fa-cog mr-1"></i>}
              {item.label}
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
}
