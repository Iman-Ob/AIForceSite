import Navigation from "@/components/navigation";
import LandingSection from "@/components/landing-section";
import MissionSection from "@/components/mission-section";
import VisionSection from "@/components/vision-section";
import ProductsSection from "@/components/products-section";
import ServicesSection from "@/components/services-section";
import ContactSection from "@/components/contact-section";
import AdminSection from "@/components/admin-section";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="font-inter bg-tactical-900 text-tactical-100">
      <Navigation />
      <LandingSection />
      <MissionSection />
      <VisionSection />
      <ProductsSection />
      <ServicesSection />
      <ContactSection />
      <AdminSection />
      <Footer />
    </div>
  );
}
