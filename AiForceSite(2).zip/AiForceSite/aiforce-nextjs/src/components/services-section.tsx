'use client'

import { useQuery } from "@tanstack/react-query";
import { Service } from "@/lib/schema";

export default function ServicesSection() {
  const { data: services, isLoading } = useQuery<Service[]>({
    queryKey: ["/api/services"],
  });

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price);
  };

  const getIconColor = (icon: string) => {
    const colors = {
      "fas fa-laptop-code": "bg-mission-blue",
      "fas fa-users-cog": "bg-mission-green", 
      "fas fa-shield-alt": "bg-mission-orange",
      "fas fa-graduation-cap": "bg-purple-600",
    };
    return colors[icon as keyof typeof colors] || "bg-mission-blue";
  };

  if (isLoading) {
    return (
      <section id="services" className="py-20 bg-tactical-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold text-tactical-100 mb-6">
              <i className="fas fa-cogs text-mission-blue mr-4"></i>OUR SERVICES
            </h2>
            <div className="w-24 h-1 bg-mission-blue mx-auto mb-8"></div>
          </div>
          <div className="grid lg:grid-cols-2 gap-8">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="bg-tactical-800 rounded-xl p-8 animate-pulse">
                <div className="h-8 bg-tactical-700 rounded mb-6"></div>
                <div className="h-4 bg-tactical-700 rounded mb-4"></div>
                <div className="h-4 bg-tactical-700 rounded mb-4"></div>
                <div className="h-4 bg-tactical-700 rounded mb-4"></div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="services" className="py-20 bg-tactical-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-tactical-100 mb-6">
            <i className="fas fa-cogs text-mission-blue mr-4"></i>TACTICAL OPERATIONS
          </h2>
          <div className="w-24 h-1 bg-mission-blue mx-auto mb-8"></div>
          <p className="text-xl text-tactical-300 max-w-3xl mx-auto">
            Comprehensive support for your AI transformation journey
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {services?.map((service) => (
            <div key={service.id} className="bg-tactical-800 rounded-xl p-8 border border-tactical-700 hover:border-mission-blue transition-all duration-300">
              <div className="flex items-center mb-6">
                <div className={`w-12 h-12 ${getIconColor(service.icon)} rounded-lg flex items-center justify-center mr-4`}>
                  <i className={`${service.icon} text-xl text-white`}></i>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-tactical-100">{service.name}</h3>
                  <p className="text-tactical-400">{service.category}</p>
                </div>
              </div>
              <p className="text-tactical-300 mb-6">{service.description}</p>
              <div className="space-y-3 mb-6">
                {service.features?.map((feature, index) => (
                  <div key={index} className="flex items-center text-tactical-300">
                    <i className={`fas fa-star ${getIconColor(service.icon).replace('bg-', 'text-')} mr-3`}></i>
                    {feature}
                  </div>
                ))}
              </div>
              <div className="border-t border-tactical-700 pt-6">
                <div className="flex items-center justify-between">
                  <span className="text-tactical-400">Starting from</span>
                  <span className={`text-2xl font-bold ${getIconColor(service.icon).replace('bg-', 'text-')}`}>
                    {formatPrice(service.startingPrice)}
                  </span>
                </div>
                <button className={`w-full mt-4 ${getIconColor(service.icon)} hover:opacity-80 text-white py-3 rounded-lg transition-all duration-200`}>
                  Get Quote
                </button>
              </div>
            </div>
          ))}
        </div>

        {!services || services.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-tactical-400 text-lg">No services currently available. Check admin panel to add services.</p>
          </div>
        ) : null}
      </div>
    </section>
  );
}
