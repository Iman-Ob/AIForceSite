import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        'tactical': {
          50: 'hsl(0, 0%, 95%)',
          100: 'hsl(0, 0%, 85%)',
          200: 'hsl(0, 0%, 75%)',
          300: 'hsl(0, 0%, 65%)',
          400: 'hsl(0, 0%, 45%)',
          500: 'hsl(0, 0%, 35%)',
          600: 'hsl(0, 0%, 25%)',
          700: 'hsl(0, 0%, 15%)',
          800: 'hsl(0, 0%, 10%)',
          900: 'hsl(0, 0%, 5%)',
        },
        'mission-blue': 'hsl(217, 91%, 60%)',
        'mission-green': 'hsl(142, 76%, 36%)',
        'mission-orange': 'hsl(25, 95%, 53%)',
      },
    },
  },
  plugins: [],
}
export default config