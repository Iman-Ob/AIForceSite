import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { insertContactSchema, type InsertContact } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function ContactSection() {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<InsertContact>({
    resolver: zodResolver(insertContactSchema),
    defaultValues: {
      name: "",
      organization: "",
      email: "aiforcetechnical@gmail.com",
      missionType: "",
      message: "",
    },
  });

  const contactMutation = useMutation({
    mutationFn: async (data: InsertContact) => {
      return await apiRequest("POST", "/api/contacts", data);
    },
    onSuccess: () => {
      toast({
        title: "Message Sent",
        description: "Your message has been received. We'll respond within 24 hours.",
      });
      form.reset();
      setIsSubmitting(false);
    },
    onError: (error) => {
      toast({
        title: "Send Failed",
        description: "Failed to send your message. Please try again.",
        variant: "destructive",
      });
      setIsSubmitting(false);
    },
  });

  const handleSubmit = (data: InsertContact) => {
    setIsSubmitting(true);
    contactMutation.mutate(data);
  };

  const contactInfo = [
    {
      icon: "fas fa-building",
      color: "mission-blue",
      title: "Office",
      content: "Mashrou Dummar"
    },
    {
      icon: "fas fa-phone",
      color: "mission-green", 
      title: "Phone & WhatsApp",
      content: "+963955757784"
    },
    {
      icon: "fas fa-envelope",
      color: "mission-orange",
      title: "Email",
      content: "aiforcetechnical@gmail.com"
    }
  ];

  const operationHours = [
    { days: "Monday - Friday", hours: "0800 - 2000 PST" },
    { days: "Saturday", hours: "1000 - 1600 PST" },
    { days: "Sunday", hours: "Emergency Only" }
  ];

  return (
    <section id="contact" className="py-20 bg-tactical-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-tactical-100 mb-6">
            <i className="fas fa-phone text-mission-blue mr-4"></i>CONTACT US
          </h2>
          <div className="w-24 h-1 bg-mission-blue mx-auto mb-8"></div>
          <p className="text-xl text-tactical-300 max-w-3xl mx-auto">
            Get in touch with our team to discuss your AI needs
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div className="bg-tactical-700 rounded-xl p-8">
            <h3 className="text-2xl font-bold text-tactical-100 mb-6">
              <i className="fas fa-envelope text-mission-blue mr-2"></i>Contact Form
            </h3>
            
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-tactical-300 mb-2">Name</label>
                  <Input
                    {...form.register("name")}
                    placeholder="Your Name"
                    className="w-full bg-tactical-800 border border-tactical-600 rounded-lg px-4 py-3 text-tactical-100 focus:border-mission-blue focus:outline-none"
                  />
                  {form.formState.errors.name && (
                    <p className="text-red-400 text-sm mt-1">{form.formState.errors.name.message}</p>
                  )}
                </div>
                <div>
                  <label className="block text-tactical-300 mb-2">Organization</label>
                  <Input
                    {...form.register("organization")}
                    placeholder="Company Name"
                    className="w-full bg-tactical-800 border border-tactical-600 rounded-lg px-4 py-3 text-tactical-100 focus:border-mission-blue focus:outline-none"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-tactical-300 mb-2">Email</label>
                <Input
                  {...form.register("email")}
                  type="email"
                  placeholder="your.email@company.com"
                  className="w-full bg-tactical-800 border border-tactical-600 rounded-lg px-4 py-3 text-tactical-100 focus:border-mission-blue focus:outline-none"
                />
                {form.formState.errors.email && (
                  <p className="text-red-400 text-sm mt-1">{form.formState.errors.email.message}</p>
                )}
              </div>
              
              <div>
                <label className="block text-tactical-300 mb-2">Service Type</label>
                <Select onValueChange={(value) => form.setValue("missionType", value)}>
                  <SelectTrigger className="w-full bg-tactical-800 border border-tactical-600 rounded-lg px-4 py-3 text-tactical-100 focus:border-mission-blue">
                    <SelectValue placeholder="Select Service Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="AI Development">AI Development</SelectItem>
                    <SelectItem value="Strategic Consulting">Strategic Consulting</SelectItem>
                    <SelectItem value="Security Assessment">Security Assessment</SelectItem>
                    <SelectItem value="Training Program">Training Program</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
                {form.formState.errors.missionType && (
                  <p className="text-red-400 text-sm mt-1">{form.formState.errors.missionType.message}</p>
                )}
              </div>
              
              <div>
                <label className="block text-tactical-300 mb-2">Message</label>
                <Textarea
                  {...form.register("message")}
                  rows={4}
                  placeholder="Describe your project requirements..."
                  className="w-full bg-tactical-800 border border-tactical-600 rounded-lg px-4 py-3 text-tactical-100 focus:border-mission-blue focus:outline-none resize-none"
                />
                {form.formState.errors.message && (
                  <p className="text-red-400 text-sm mt-1">{form.formState.errors.message.message}</p>
                )}
              </div>
              
              <Button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-mission-blue hover:bg-blue-600 text-white py-4 rounded-lg font-semibold transition-colors duration-200"
              >
                <i className="fas fa-paper-plane mr-2"></i>
                {isSubmitting ? "Sending..." : "Send Message"}
              </Button>
            </form>
          </div>

          {/* Contact Information */}
          <div className="space-y-8">
            <div className="bg-tactical-700 rounded-xl p-8">
              <h3 className="text-2xl font-bold text-tactical-100 mb-6">
                <i className="fas fa-map-marker-alt text-mission-blue mr-2"></i>Contact Information
              </h3>
              
              <div className="space-y-6">
                {contactInfo.map((info, index) => (
                  <div key={index} className="flex items-start space-x-4">
                    <div className={`w-10 h-10 bg-${info.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
                      <i className={`${info.icon} text-white`}></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-tactical-100">{info.title}</h4>
                      <p className="text-tactical-300 whitespace-pre-line">{info.content}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-tactical-700 rounded-xl p-8">
              <h3 className="text-2xl font-bold text-tactical-100 mb-6">
                <i className="fas fa-clock text-mission-blue mr-2"></i>Business Hours
              </h3>
              
              <div className="space-y-3">
                {operationHours.map((schedule, index) => (
                  <div key={index} className="flex justify-between items-center">
                    <span className="text-tactical-300">{schedule.days}</span>
                    <span className={`font-semibold ${schedule.hours === "Closed" ? "text-tactical-400" : "text-tactical-100"}`}>
                      {schedule.hours}
                    </span>
                  </div>
                ))}
              </div>
              
              <div className="mt-6 p-4 bg-tactical-800 rounded-lg">
                <p className="text-tactical-300 text-sm">
                  <i className="fas fa-clock text-mission-blue mr-2"></i>
                  Emergency support available for critical issues
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
