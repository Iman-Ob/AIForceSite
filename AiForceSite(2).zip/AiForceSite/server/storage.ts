import { type Product, type InsertProduct, type Service, type InsertService, type Contact, type InsertContact } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Products
  getProducts(): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, product: Partial<InsertProduct>): Promise<Product>;
  deleteProduct(id: string): Promise<void>;

  // Services
  getServices(): Promise<Service[]>;
  createService(service: InsertService): Promise<Service>;
  updateService(id: string, service: Partial<InsertService>): Promise<Service>;
  deleteService(id: string): Promise<void>;

  // Contacts
  getContacts(): Promise<Contact[]>;
  createContact(contact: InsertContact): Promise<Contact>;
}

export class MemStorage implements IStorage {
  private products: Map<string, Product>;
  private services: Map<string, Service>;
  private contacts: Map<string, Contact>;

  constructor() {
    this.products = new Map();
    this.services = new Map();
    this.contacts = new Map();

    // Initialize with some default data
    this.seedData();
  }

  private async seedData() {
    // Default products
    const defaultProducts: Product[] = [
      {
        id: randomUUID(),
        name: "AI Assistant Platform",
        description: "Intelligent AI agents that automate complex business processes and workflows.",
        status: "DEPLOYED",
        features: ["Multi-agent coordination", "Real-time decision making", "Enterprise integration"]
      },
      {
        id: randomUUID(),
        name: "Workflow Automation",
        description: "Intelligent automation platform that streamlines business processes and reduces manual work.",
        status: "ACTIVE",
        features: ["Process optimization", "Predictive analytics", "Custom workflows"]
      },
      {
        id: randomUUID(),
        name: "Analytics Dashboard",
        description: "Real-time business intelligence with enterprise-grade analytics and reporting.",
        status: "BETA",
        features: ["Live data streams", "Advanced visualizations", "Anomaly detection"]
      }
    ];

    // Default services
    const defaultServices: Service[] = [
      {
        id: randomUUID(),
        name: "Custom AI Development",
        category: "Development Team",
        description: "Tailored AI solutions built to your specifications. Our experienced development team creates cutting-edge technology for maximum business impact.",
        features: [
          "Requirements analysis & strategic planning",
          "Custom model development & training", 
          "Integration & deployment support",
          "Ongoing maintenance & optimization"
        ],
        startingPrice: 12500,
        icon: "fas fa-laptop-code"
      },
      {
        id: randomUUID(),
        name: "AI Consulting & Strategy",
        category: "Strategy & Consulting",
        description: "Strategic guidance from our AI experts. We analyze your business needs and develop comprehensive AI transformation strategies.",
        features: [
          "AI readiness assessment",
          "Technology roadmap development",
          "ROI optimization strategies", 
          "Implementation oversight"
        ],
        startingPrice: 2500,
        icon: "fas fa-users-cog"
      },
      {
        id: randomUUID(),
        name: "AI Security & Compliance",
        category: "Security & Compliance",
        description: "Enterprise-grade security protocols for your AI infrastructure. Comprehensive security assessment and compliance frameworks for business-critical systems.",
        features: [
          "Security vulnerability assessment",
          "Compliance framework implementation",
          "Data protection protocols",
          "Ongoing security monitoring"
        ],
        startingPrice: 7500,
        icon: "fas fa-shield-alt"
      },
      {
        id: randomUUID(),
        name: "AI Training & Support",
        category: "Training & Support",
        description: "Comprehensive training programs to build your team's AI capabilities. From basic concepts to advanced implementation strategies.",
        features: [
          "Custom training curricula",
          "Hands-on workshop sessions",
          "Certification programs",
          "Ongoing technical support"
        ],
        startingPrice: 4000,
        icon: "fas fa-graduation-cap"
      }
    ];

    defaultProducts.forEach(product => this.products.set(product.id, product));
    defaultServices.forEach(service => this.services.set(service.id, service));
  }

  // Products
  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = randomUUID();
    const product: Product = { 
      ...insertProduct, 
      id,
      features: insertProduct.features || []
    };
    this.products.set(id, product);
    return product;
  }

  async updateProduct(id: string, updates: Partial<InsertProduct>): Promise<Product> {
    const product = this.products.get(id);
    if (!product) {
      throw new Error("Product not found");
    }
    const updatedProduct = { ...product, ...updates };
    this.products.set(id, updatedProduct);
    return updatedProduct;
  }

  async deleteProduct(id: string): Promise<void> {
    this.products.delete(id);
  }

  // Services
  async getServices(): Promise<Service[]> {
    return Array.from(this.services.values());
  }

  async createService(insertService: InsertService): Promise<Service> {
    const id = randomUUID();
    const service: Service = { 
      ...insertService, 
      id,
      features: insertService.features || [],
      icon: insertService.icon || "fas fa-cogs"
    };
    this.services.set(id, service);
    return service;
  }

  async updateService(id: string, updates: Partial<InsertService>): Promise<Service> {
    const service = this.services.get(id);
    if (!service) {
      throw new Error("Service not found");
    }
    const updatedService = { ...service, ...updates };
    this.services.set(id, updatedService);
    return updatedService;
  }

  async deleteService(id: string): Promise<void> {
    this.services.delete(id);
  }

  // Contacts
  async getContacts(): Promise<Contact[]> {
    return Array.from(this.contacts.values());
  }

  async createContact(insertContact: InsertContact): Promise<Contact> {
    const id = randomUUID();
    const contact: Contact = { 
      ...insertContact, 
      id,
      organization: insertContact.organization || null,
      createdAt: new Date().toISOString()
    };
    this.contacts.set(id, contact);
    return contact;
  }
}

import { DatabaseStorage } from "./databaseStorage";

export const storage = process.env.DATABASE_URL ? new DatabaseStorage() : new MemStorage();
