'use client'

import { useQuery } from "@tanstack/react-query";
import { Product } from "@/lib/schema";

export default function ProductsSection() {
  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "DEPLOYED":
        return "bg-mission-green text-white";
      case "ACTIVE":
        return "bg-mission-blue text-white";
      case "BETA":
        return "bg-mission-orange text-white";
      case "DEVELOPMENT":
        return "bg-tactical-600 text-tactical-200";
      default:
        return "bg-tactical-600 text-tactical-200";
    }
  };

  if (isLoading) {
    return (
      <section id="products" className="py-20 bg-tactical-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold text-tactical-100 mb-6">
              <i className="fas fa-rocket text-mission-blue mr-4"></i>OUR PRODUCTS
            </h2>
            <div className="w-24 h-1 bg-mission-blue mx-auto mb-8"></div>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-tactical-700 rounded-xl p-6 animate-pulse">
                <div className="h-6 bg-tactical-600 rounded mb-4"></div>
                <div className="h-4 bg-tactical-600 rounded mb-4"></div>
                <div className="h-4 bg-tactical-600 rounded mb-2"></div>
                <div className="h-4 bg-tactical-600 rounded mb-2"></div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="products" className="py-20 bg-tactical-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-tactical-100 mb-6">
            <i className="fas fa-rocket text-mission-blue mr-4"></i>OUR ARSENAL
          </h2>
          <div className="w-24 h-1 bg-mission-blue mx-auto mb-8"></div>
          <p className="text-xl text-tactical-300 max-w-3xl mx-auto">
            Powerful AI solutions designed for maximum business effectiveness
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products?.map((product) => (
            <div key={product.id} className="bg-tactical-700 rounded-xl overflow-hidden hover:bg-tactical-600 transition-all duration-300 transform hover:scale-105">
              <div className="p-6 border-b border-tactical-600">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-bold text-tactical-100">{product.name}</h3>
                  <span className={`px-2 py-1 text-xs rounded-full ${getStatusColor(product.status)}`}>
                    {product.status}
                  </span>
                </div>
                <p className="text-tactical-300 mb-4">{product.description}</p>
                <div className="space-y-2">
                  {product.features?.map((feature, index) => (
                    <div key={index} className="flex items-center text-sm text-tactical-400">
                      <i className="fas fa-check text-mission-green mr-2"></i>
                      {feature}
                    </div>
                  ))}
                </div>
              </div>
              <div className="p-6">
                <button className="w-full bg-mission-blue hover:bg-blue-600 text-white py-2 rounded-lg transition-colors duration-200">
                  Learn More
                </button>
              </div>
            </div>
          ))}
        </div>

        {!products || products.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-tactical-400 text-lg">No products available. Check admin panel to add products.</p>
          </div>
        ) : null}
      </div>
    </section>
  );
}
