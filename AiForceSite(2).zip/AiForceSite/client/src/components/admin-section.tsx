import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Product, Service, insertProductSchema, insertServiceSchema, type InsertProduct, type InsertService } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function AdminSection() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [activeTab, setActiveTab] = useState("products");
  const [editingProduct, setEditingProduct] = useState<string | null>(null);
  const [editingService, setEditingService] = useState<string | null>(null);
  const { toast } = useToast();

  const { data: products, isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const { data: services, isLoading: servicesLoading } = useQuery<Service[]>({
    queryKey: ["/api/services"],
  });

  const productForm = useForm<any>({
    defaultValues: {
      name: "",
      description: "",
      status: "DEVELOPMENT",
      features: "",
    },
  });

  const serviceForm = useForm<InsertService>({
    resolver: zodResolver(insertServiceSchema),
    defaultValues: {
      name: "",
      category: "",
      description: "",
      features: [],
      startingPrice: 2500,
      icon: "fas fa-cogs",
    },
  });

  const createProductMutation = useMutation({
    mutationFn: async (data: InsertProduct) => {
      return await apiRequest("POST", "/api/products", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({ title: "Product added successfully" });
      productForm.reset();
    },
    onError: () => {
      toast({ title: "Failed to add product", variant: "destructive" });
    },
  });

  const updateProductMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: any }) => {
      return await apiRequest("PUT", `/api/products/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      setEditingProduct(null);
      toast({ title: "Product updated successfully" });
    },
    onError: () => {
      toast({ title: "Failed to update product", variant: "destructive" });
    },
  });

  const deleteProductMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/products/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({ title: "Product removed successfully" });
    },
    onError: (error) => {
      toast({ title: "Failed to remove product", variant: "destructive" });
    },
  });

  const createServiceMutation = useMutation({
    mutationFn: async (data: InsertService) => {
      return await apiRequest("POST", "/api/services", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/services"] });
      toast({ title: "Service added successfully" });
      serviceForm.reset();
    },
    onError: () => {
      toast({ title: "Failed to add service", variant: "destructive" });
    },
  });

  const updateServiceMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: any }) => {
      return await apiRequest("PUT", `/api/services/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/services"] });
      setEditingService(null);
      toast({ title: "Service updated successfully" });
    },
    onError: () => {
      toast({ title: "Failed to update service", variant: "destructive" });
    },
  });

  const deleteServiceMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/services/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/services"] });
      toast({ title: "Service removed successfully" });
    },
    onError: (error) => {
      toast({ title: "Failed to remove service", variant: "destructive" });
    },
  });

  const handleProductSubmit = (data: InsertProduct) => {
    const featuresArray = typeof data.features === 'string' 
      ? (data.features as string).split('\n').filter(f => f.trim())
      : data.features;
    
    createProductMutation.mutate({
      ...data,
      features: featuresArray
    });
  };

  const handleServiceSubmit = (data: InsertService) => {
    const featuresArray = typeof data.features === 'string' 
      ? (data.features as string).split('\n').filter(f => f.trim())
      : data.features;
    
    createServiceMutation.mutate({
      ...data,
      features: featuresArray
    });
  };

  const startEditingProduct = (product: Product) => {
    setEditingProduct(product.id);
    productForm.reset({
      name: product.name,
      description: product.description,
      status: product.status,
      features: (product.features || []).join('\n'),
    });
  };

  const startEditingService = (service: Service) => {
    setEditingService(service.id);
    serviceForm.reset({
      name: service.name,
      category: service.category,
      description: service.description,
      features: service.features || [],
      startingPrice: service.startingPrice,
      icon: service.icon,
    });
  };

  const handleProductUpdate = (data: InsertProduct) => {
    if (!editingProduct) return;
    const featuresArray = typeof data.features === 'string' 
      ? (data.features as string).split('\n').filter(f => f.trim())
      : data.features;
    
    updateProductMutation.mutate({
      id: editingProduct,
      data: { ...data, features: featuresArray }
    });
  };

  const handleServiceUpdate = (data: InsertService) => {
    if (!editingService) return;
    const featuresArray = typeof data.features === 'string' 
      ? (data.features as string).split('\n').filter(f => f.trim())
      : data.features;
    
    updateServiceMutation.mutate({
      id: editingService,
      data: { ...data, features: featuresArray }
    });
  };

  const adminTabs = [
    { id: "products", label: "Manage Products", icon: "fas fa-rocket" },
    { id: "services", label: "Manage Services", icon: "fas fa-cogs" },
    { id: "analytics", label: "Analytics", icon: "fas fa-chart-line" },
    { id: "settings", label: "Settings", icon: "fas fa-sliders-h" },
  ];

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === "admin" && password === "master") {
      setIsAuthenticated(true);
      toast({ title: "Access granted", description: "Welcome to the admin panel" });
    } else {
      toast({ 
        title: "Access denied", 
        description: "Invalid credentials", 
        variant: "destructive" 
      });
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setUsername("");
    setPassword("");
    toast({ title: "Logged out", description: "You have been logged out of the admin panel" });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "DEPLOYED": return "bg-mission-green text-white";
      case "ACTIVE": return "bg-mission-blue text-white";
      case "BETA": return "bg-mission-orange text-white";
      case "DEVELOPMENT": return "bg-tactical-600 text-tactical-200";
      default: return "bg-tactical-600 text-tactical-200";
    }
  };

  // Show login form if not authenticated
  if (!isAuthenticated) {
    return (
      <section id="admin" className="py-20 bg-tactical-900 min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold text-tactical-100 mb-6">
              <i className="fas fa-lock text-mission-orange mr-4"></i>ADMIN ACCESS
            </h2>
            <div className="w-24 h-1 bg-mission-orange mx-auto mb-8"></div>
            <p className="text-xl text-tactical-300 max-w-3xl mx-auto">
              Authentication required for administrative access
            </p>
          </div>

          <div className="max-w-md mx-auto">
            <div className="bg-tactical-800 rounded-xl p-8 shadow-2xl">
              <h3 className="text-2xl font-bold text-tactical-100 mb-6 text-center">
                <i className="fas fa-shield-alt text-mission-blue mr-2"></i>Secure Login
              </h3>
              
              <form onSubmit={handleLogin} className="space-y-6">
                <div>
                  <label className="block text-tactical-300 mb-2 font-semibold">Username</label>
                  <Input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Enter username"
                    className="w-full bg-tactical-700 border border-tactical-600 rounded-lg px-4 py-3 text-tactical-100 focus:border-mission-blue focus:ring-2 focus:ring-mission-blue/20"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-tactical-300 mb-2 font-semibold">Password</label>
                  <Input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter password"
                    className="w-full bg-tactical-700 border border-tactical-600 rounded-lg px-4 py-3 text-tactical-100 focus:border-mission-blue focus:ring-2 focus:ring-mission-blue/20"
                    required
                  />
                </div>
                
                <Button
                  type="submit"
                  className="w-full bg-mission-blue hover:bg-blue-600 text-white py-3 rounded-lg font-semibold text-lg transition-all duration-300"
                >
                  <i className="fas fa-sign-in-alt mr-2"></i>Access Admin Panel
                </Button>
              </form>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="admin" className="py-20 bg-tactical-900 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="flex justify-between items-center mb-6">
            <div className="flex-1"></div>
            <h2 className="text-3xl md:text-5xl font-bold text-tactical-100 flex-1">
              <i className="fas fa-cog text-mission-orange mr-4"></i>ADMIN PANEL
            </h2>
            <div className="flex-1 flex justify-end">
              <Button
                onClick={handleLogout}
                variant="outline"
                className="bg-transparent border-red-400 text-red-400 hover:bg-red-400 hover:text-white"
              >
                <i className="fas fa-sign-out-alt mr-2"></i>Logout
              </Button>
            </div>
          </div>
          <div className="w-24 h-1 bg-mission-orange mx-auto mb-8"></div>
          <p className="text-xl text-tactical-300 max-w-3xl mx-auto">
            Administrative dashboard for managing products and services
          </p>
        </div>

        {/* Admin Navigation */}
        <div className="bg-tactical-800 rounded-xl p-6 mb-8">
          <div className="flex flex-wrap gap-4">
            {adminTabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-6 py-3 rounded-lg font-semibold transition-colors duration-200 ${
                  activeTab === tab.id
                    ? "bg-mission-orange text-white shadow-lg"
                    : "bg-tactical-700 text-tactical-300 hover:bg-tactical-600"
                }`}
              >
                <i className={`${tab.icon} mr-2`}></i>
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Products Management */}
        {activeTab === "products" && (
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Add Product Form */}
            <div className="lg:col-span-1">
              <div className="bg-tactical-800 rounded-xl p-6">
                <h3 className="text-xl font-bold text-tactical-100 mb-6">
                  <i className={`fas ${editingProduct ? 'fa-edit' : 'fa-plus'} text-mission-blue mr-2`}></i>{editingProduct ? 'Edit Product' : 'Add New Product'}
                </h3>
                
                <form onSubmit={productForm.handleSubmit(editingProduct ? handleProductUpdate : handleProductSubmit)} className="space-y-4">
                  <div>
                    <label className="block text-tactical-300 mb-2">Product Name</label>
                    <Input
                      {...productForm.register("name")}
                      placeholder="AI Product Name"
                      className="w-full bg-tactical-700 border border-tactical-600 rounded-lg px-4 py-3 text-tactical-100 focus:border-mission-blue"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-tactical-300 mb-2">Status</label>
                    <Select onValueChange={(value) => productForm.setValue("status", value)}>
                      <SelectTrigger className="w-full bg-tactical-700 border border-tactical-600 rounded-lg px-4 py-3 text-tactical-100 focus:border-mission-blue">
                        <SelectValue placeholder="DEVELOPMENT" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="DEPLOYED">DEPLOYED</SelectItem>
                        <SelectItem value="ACTIVE">ACTIVE</SelectItem>
                        <SelectItem value="BETA">BETA</SelectItem>
                        <SelectItem value="DEVELOPMENT">DEVELOPMENT</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <label className="block text-tactical-300 mb-2">Description</label>
                    <Textarea
                      {...productForm.register("description")}
                      rows={3}
                      placeholder="Product capabilities..."
                      className="w-full bg-tactical-700 border border-tactical-600 rounded-lg px-4 py-3 text-tactical-100 focus:border-mission-blue resize-none"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-tactical-300 mb-2">Features (one per line)</label>
                    <Textarea
                      {...productForm.register("features")}
                      rows={3}
                      placeholder="Feature 1&#10;Feature 2&#10;Feature 3"
                      className="w-full bg-tactical-700 border border-tactical-600 rounded-lg px-4 py-3 text-tactical-100 focus:border-mission-blue resize-none"
                    />
                  </div>
                  
                  <div className="flex gap-2">
                    <Button
                      type="submit"
                      disabled={createProductMutation.isPending || updateProductMutation.isPending}
                      className="flex-1 bg-mission-blue hover:bg-blue-600 text-white py-3 rounded-lg font-semibold"
                    >
                      <i className="fas fa-rocket mr-2"></i>
                      {editingProduct 
                        ? (updateProductMutation.isPending ? "Updating..." : "Update Product")
                        : (createProductMutation.isPending ? "Adding..." : "Add Product")
                      }
                    </Button>
                    {editingProduct && (
                      <Button
                        type="button"
                        onClick={() => {
                          setEditingProduct(null);
                          productForm.reset();
                        }}
                        variant="outline"
                        className="py-3 px-4"
                      >
                        Cancel
                      </Button>
                    )}
                  </div>
                </form>
              </div>
            </div>

            {/* Products List */}
            <div className="lg:col-span-2">
              <div className="bg-tactical-800 rounded-xl p-6">
                <h3 className="text-xl font-bold text-tactical-100 mb-6">
                  <i className="fas fa-list text-mission-blue mr-2"></i>Current Products
                </h3>
                
                {productsLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="bg-tactical-700 rounded-lg p-4 animate-pulse">
                        <div className="h-6 bg-tactical-600 rounded mb-2"></div>
                        <div className="h-4 bg-tactical-600 rounded"></div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {products?.map((product) => (
                      <div key={product.id} className="bg-tactical-700 rounded-lg p-4 flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-4">
                            <h4 className="font-semibold text-tactical-100">{product.name}</h4>
                            <span className={`px-2 py-1 text-xs rounded-full ${getStatusColor(product.status)}`}>
                              {product.status}
                            </span>
                          </div>
                          <p className="text-tactical-400 text-sm mt-1">{product.description}</p>
                        </div>
                        <div className="flex space-x-2">
                          <button 
                            onClick={() => startEditingProduct(product)}
                            className="text-mission-blue hover:text-blue-400 p-2"
                          >
                            <i className="fas fa-pen"></i>
                          </button>
                          <button 
                            onClick={() => deleteProductMutation.mutate(product.id)}
                            className="text-red-400 hover:text-red-300 p-2"
                          >
                            <i className="fas fa-recycle"></i>
                          </button>
                        </div>
                      </div>
                    ))}
                    
                    {!products || products.length === 0 ? (
                      <p className="text-tactical-400 text-center py-8">No products available. Add your first product above.</p>
                    ) : null}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Services Management */}
        {activeTab === "services" && (
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-1">
              <div className="bg-tactical-800 rounded-xl p-6">
                <h3 className="text-xl font-bold text-tactical-100 mb-6">
                  <i className={`fas ${editingService ? 'fa-edit' : 'fa-plus'} text-mission-green mr-2`}></i>{editingService ? 'Edit Service' : 'Add New Service'}
                </h3>
                
                <form onSubmit={serviceForm.handleSubmit(editingService ? handleServiceUpdate : handleServiceSubmit)} className="space-y-4">
                  <div>
                    <label className="block text-tactical-300 mb-2">Operation Name</label>
                    <Input
                      {...serviceForm.register("name")}
                      placeholder="Service Name"
                      className="w-full bg-tactical-700 border border-tactical-600 rounded-lg px-4 py-3 text-tactical-100 focus:border-mission-blue"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-tactical-300 mb-2">Operation Type</label>
                    <Input
                      {...serviceForm.register("category")}
                      placeholder="Service Category"
                      className="w-full bg-tactical-700 border border-tactical-600 rounded-lg px-4 py-3 text-tactical-100 focus:border-mission-blue"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-tactical-300 mb-2">Description</label>
                    <Textarea
                      {...serviceForm.register("description")}
                      rows={3}
                      placeholder="Operation description..."
                      className="w-full bg-tactical-700 border border-tactical-600 rounded-lg px-4 py-3 text-tactical-100 focus:border-mission-blue resize-none"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-tactical-300 mb-2">Features</label>
                    <Textarea
                      {...serviceForm.register("features")}
                      onChange={(e) => serviceForm.setValue("features", e.target.value.split('\n').filter(f => f.trim()))}
                      rows={3}
                      placeholder="Feature 1&#10;Feature 2&#10;Feature 3"
                      value={editingService && serviceForm.getValues("features") ? serviceForm.getValues("features")?.join('\n') : ""}
                      className="w-full bg-tactical-700 border border-tactical-600 rounded-lg px-4 py-3 text-tactical-100 focus:border-mission-blue resize-none"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-tactical-300 mb-2">Starting Price</label>
                    <Input
                      {...serviceForm.register("startingPrice", { valueAsNumber: true })}
                      type="number"
                      placeholder="5000"
                      className="w-full bg-tactical-700 border border-tactical-600 rounded-lg px-4 py-3 text-tactical-100 focus:border-mission-blue"
                    />
                  </div>

                  <div>
                    <label className="block text-tactical-300 mb-2">Icon</label>
                    <Select onValueChange={(value) => serviceForm.setValue("icon", value)}>
                      <SelectTrigger className="w-full bg-tactical-700 border border-tactical-600 rounded-lg px-4 py-3 text-tactical-100 focus:border-mission-blue">
                        <SelectValue placeholder="fas fa-cogs" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="fas fa-laptop-code">fas fa-laptop-code</SelectItem>
                        <SelectItem value="fas fa-users-cog">fas fa-users-cog</SelectItem>
                        <SelectItem value="fas fa-shield-alt">fas fa-shield-alt</SelectItem>
                        <SelectItem value="fas fa-graduation-cap">fas fa-graduation-cap</SelectItem>
                        <SelectItem value="fas fa-cogs">fas fa-cogs</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button
                      type="submit"
                      disabled={createServiceMutation.isPending || updateServiceMutation.isPending}
                      className="flex-1 bg-mission-green hover:bg-green-600 text-white py-3 rounded-lg font-semibold"
                    >
                      <i className="fas fa-cogs mr-2"></i>
                      {editingService 
                        ? (updateServiceMutation.isPending ? "Updating..." : "Update Service")
                        : (createServiceMutation.isPending ? "Adding..." : "Add Service")
                      }
                    </Button>
                    {editingService && (
                      <Button
                        type="button"
                        onClick={() => {
                          setEditingService(null);
                          serviceForm.reset();
                        }}
                        variant="outline"
                        className="py-3 px-4"
                      >
                        Cancel
                      </Button>
                    )}
                  </div>
                </form>
              </div>
            </div>

            <div className="lg:col-span-2">
              <div className="bg-tactical-800 rounded-xl p-6">
                <h3 className="text-xl font-bold text-tactical-100 mb-6">
                  <i className="fas fa-list text-mission-green mr-2"></i>Active Operations
                </h3>
                
                {servicesLoading ? (
                  <div className="space-y-4">
                    {[1, 2].map((i) => (
                      <div key={i} className="bg-tactical-700 rounded-lg p-4 animate-pulse">
                        <div className="h-6 bg-tactical-600 rounded mb-2"></div>
                        <div className="h-4 bg-tactical-600 rounded"></div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {services?.map((service) => (
                      <div key={service.id} className="bg-tactical-700 rounded-lg p-4 flex items-center justify-between">
                        <div className="flex-1">
                          <h4 className="font-semibold text-tactical-100">{service.name}</h4>
                          <p className="text-tactical-400 text-sm mt-1">Starting from ${service.startingPrice.toLocaleString()}</p>
                        </div>
                        <div className="flex space-x-2">
                          <button 
                            onClick={() => startEditingService(service)}
                            className="text-mission-blue hover:text-blue-400 p-2"
                          >
                            <i className="fas fa-pen"></i>
                          </button>
                          <button 
                            onClick={() => deleteServiceMutation.mutate(service.id)}
                            className="text-red-400 hover:text-red-300 p-2"
                          >
                            <i className="fas fa-recycle"></i>
                          </button>
                        </div>
                      </div>
                    ))}

                    {!services || services.length === 0 ? (
                      <p className="text-tactical-400 text-center py-8">No services available. Add your first service above.</p>
                    ) : null}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Analytics Tab */}
        {activeTab === "analytics" && (
          <div className="grid lg:grid-cols-2 gap-8">
            <div className="bg-tactical-800 rounded-xl p-6">
              <h3 className="text-xl font-bold text-tactical-100 mb-6">
                <i className="fas fa-chart-line text-mission-blue mr-2"></i>Mission Metrics
              </h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-4 bg-tactical-700 rounded-lg">
                  <span className="text-tactical-300">Total Products</span>
                  <span className="text-2xl font-bold text-mission-blue">{products?.length || 0}</span>
                </div>
                <div className="flex justify-between items-center p-4 bg-tactical-700 rounded-lg">
                  <span className="text-tactical-300">Active Services</span>
                  <span className="text-2xl font-bold text-mission-green">{services?.length || 0}</span>
                </div>
                <div className="flex justify-between items-center p-4 bg-tactical-700 rounded-lg">
                  <span className="text-tactical-300">Platform Status</span>
                  <span className="text-2xl font-bold text-mission-orange">OPERATIONAL</span>
                </div>
              </div>
            </div>
            
            <div className="bg-tactical-800 rounded-xl p-6">
              <h3 className="text-xl font-bold text-tactical-100 mb-6">
                <i className="fas fa-users text-mission-green mr-2"></i>Contact Intelligence
              </h3>
              <p className="text-tactical-400">Advanced analytics dashboard would display real-time contact and engagement metrics.</p>
            </div>
          </div>
        )}

        {/* Settings Tab */}
        {activeTab === "settings" && (
          <div className="bg-tactical-800 rounded-xl p-6">
            <h3 className="text-xl font-bold text-tactical-100 mb-6">
              <i className="fas fa-sliders-h text-mission-orange mr-2"></i>Platform Configuration
            </h3>
            <p className="text-tactical-400">Platform settings and configuration options would be implemented here for production use.</p>
          </div>
        )}
      </div>
    </section>
  );
}
