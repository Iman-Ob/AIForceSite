import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { services } from '@/lib/schema'
import { insertServiceSchema } from '@/lib/schema'

export async function GET() {
  try {
    const allServices = await db.select().from(services)
    return NextResponse.json(allServices)
  } catch (error) {
    console.error('Error fetching services:', error)
    return NextResponse.json({ error: 'Failed to fetch services' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    const validatedData = insertServiceSchema.parse(data)
    
    const [newService] = await db.insert(services).values(validatedData).returning()
    return NextResponse.json(newService, { status: 201 })
  } catch (error) {
    console.error('Error creating service:', error)
    return NextResponse.json({ error: 'Failed to create service' }, { status: 400 })
  }
}