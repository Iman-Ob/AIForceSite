CREATE TABLE "contacts" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"organization" text,
	"email" text NOT NULL,
	"mission_type" text NOT NULL,
	"message" text NOT NULL,
	"created_at" text DEFAULT datetime('now') NOT NULL
);
--> statement-breakpoint
CREATE TABLE "products" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"description" text NOT NULL,
	"status" varchar NOT NULL,
	"features" text[] DEFAULT ARRAY[]::text[] NOT NULL
);
--> statement-breakpoint
CREATE TABLE "services" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"category" text NOT NULL,
	"description" text NOT NULL,
	"features" text[] DEFAULT ARRAY[]::text[] NOT NULL,
	"starting_price" integer NOT NULL,
	"icon" varchar DEFAULT 'fas fa-cogs' NOT NULL
);
