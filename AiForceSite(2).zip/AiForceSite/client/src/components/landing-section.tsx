import { useRef } from 'react';
import introVideo from '@assets/AIFORCE Intro_1755743308851.mov';

export default function LandingSection() {
  const videoRef = useRef<HTMLVideoElement>(null);
  return (
    <section id="home" className="min-h-screen bg-tactical-gradient relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-10 w-96 h-96 border border-tactical-600 rounded-full"></div>
        <div className="absolute bottom-20 right-10 w-64 h-64 border border-tactical-600 rounded-full"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-128 h-128 border border-tactical-600 rounded-full"></div>
      </div>

      <div className="relative z-10 flex items-center justify-center min-h-screen pt-16">
        <div className="text-center max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Logo Section */}
          <div className="mb-8">
            <img 
              src="data:image/svg+xml,%3Csvg width='200' height='100' xmlns='http://www.w3.org/2000/svg'%3E%3Crect width='200' height='100' fill='%23a0aec0'/%3E%3Ctext x='100' y='55' font-family='Arial, sans-serif' font-size='20' font-weight='bold' text-anchor='middle' fill='%23ffffff'%3EAIFORCE%3C/text%3E%3C/svg%3E" 
              alt="AIFORCE" 
              className="mx-auto h-24 md:h-32 mb-6"
            />
          </div>

          {/* Main Tagline */}
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 text-tactical-100">
            <span className="block">GAIN TACTICAL</span>
            <span className="block text-mission-blue">SUPERIORITY</span>
            <span className="block">IN YOUR FIELD</span>
          </h1>

          {/* Subtitle */}
          <p className="text-xl md:text-2xl text-tactical-300 mb-12 max-w-3xl mx-auto">
            Smart AI solutions designed for businesses that need efficient automation and data-driven insights.
          </p>

          {/* Video Section */}
          <div className="max-w-4xl mx-auto mb-12">
            <div className="relative bg-tactical-800 rounded-2xl p-4 shadow-2xl">
              <video
                ref={videoRef}
                className="w-full aspect-video rounded-xl"
                autoPlay
                controls
                onPlay={() => {
                  if (videoRef.current) {
                    videoRef.current.scrollIntoView({ 
                      behavior: 'smooth', 
                      block: 'center' 
                    });
                  }
                }}
              >
                <source src={introVideo} type="video/quicktime" />
                <div className="aspect-video bg-tactical-700 rounded-xl flex items-center justify-center">
                  <div className="text-center">
                    <i className="fas fa-play-circle text-6xl text-mission-blue mb-4"></i>
                    <p className="text-tactical-300 text-lg font-semibold">AIFORCE Introduction</p>
                    <p className="text-sm text-tactical-400 mt-2">Video not supported</p>
                  </div>
                </div>
              </video>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
