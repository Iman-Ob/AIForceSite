import { sql } from 'drizzle-orm';
import {
  integer,
  pgTable,
  text,
  varchar,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const products = pgTable("products", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description").notNull(),
  status: varchar("status").notNull(), // DEPLOYED, ACTIVE, BETA, DEVELOPMENT
  features: text("features").array().notNull().default(sql`ARRAY[]::text[]`),
});

export const services = pgTable("services", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  category: text("category").notNull(),
  description: text("description").notNull(),
  features: text("features").array().notNull().default(sql`ARRAY[]::text[]`),
  startingPrice: integer("starting_price").notNull(),
  icon: varchar("icon").notNull().default("fas fa-cogs"),
});

export const contacts = pgTable("contacts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  organization: text("organization"),
  email: text("email").notNull(),
  missionType: text("mission_type").notNull(),
  message: text("message").notNull(),
  createdAt: text("created_at").notNull().default(sql`datetime('now')`),
});

export const insertProductSchema = createInsertSchema(products).pick({
  name: true,
  description: true,
  status: true,
  features: true,
});

export const insertServiceSchema = createInsertSchema(services).pick({
  name: true,
  category: true,
  description: true,
  features: true,
  startingPrice: true,
  icon: true,
});

export const insertContactSchema = createInsertSchema(contacts).pick({
  name: true,
  organization: true,
  email: true,
  missionType: true,
  message: true,
});

export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;
export type InsertService = z.infer<typeof insertServiceSchema>;
export type Service = typeof services.$inferSelect;
export type InsertContact = z.infer<typeof insertContactSchema>;
export type Contact = typeof contacts.$inferSelect;